# FantasyX Roadmap

This roadmap prioritizes architectural work by impact and dependency order. It assumes the product remains free-play/mock-credit until the MVP is validated.

## Project Status

Current milestone: Sprint 1 Exchange Foundation, FX-001 complete.

Overall MVP foundation completion: 70%.

Next logical milestone: FX-002 Admin Audit.

Sprint 2 focus:

- Completed: FX-001 Append-Only Ledger Foundation.
- FX-002 Admin Audit: complete the admin action model around market edits, admin adjustments, and immutable review trails.
- Concurrency-safe trade execution.
- Real charting for equity and market timelines.
- E2E smoke tests for login, trade, portfolio, and settlement.

## Completed - FX-001 Append-Only Ledger Foundation

Implemented:

- Expanded `AccountLedgerEntry` with `adminId`, `metadata`, and `CORRECTION` support.
- Added committed Prisma migration for the current schema.
- Added append-only database trigger protection for ledger update/delete attempts.
- Added `lib/ledger-service.ts` for transaction-safe balance mutation and reconciliation.
- Refactored trade spend, settlement payout, and void refund balance changes through the ledger service.
- Added idempotency-key duplicate protection before balance mutation.
- Added reconciliation utilities for one user and all users.
- Added unit coverage for pure ledger balance math.
- Added integration coverage for seed grants, trade spend ledger rows, settlement payout ledger rows, void refund ledger rows, reconciliation mismatch detail, duplicate payout/refund prevention, metadata, admin attribution, correction entries, trade history, portfolio calculations, market history, and audit records.
- Documented ledger rows as append-only. The application exposes read-only ledger access and no route/helper for editing or deleting ledger entries.

## Completed - Sprint 1 Exchange Foundation

Implemented:

- Append-only `AccountLedgerEntry` records for seed grants, trade spends, settlement payouts, and void refunds.
- Market summary fields for opening price, volume, and open interest.
- Unified `MarketEvent` records for trades, price changes, lock, unlock, settle, void, and admin notes.
- Immutable-style `AdminAuditLog` records for settlement, void, lock, and unlock actions.
- Trade History page at `/history` with week, player, position, market, and status filters.
- Market Timeline component used on `/markets` and `/history`.
- Portfolio history display for open positions, closed positions, realized P&L, unrealized P&L, average entry, current value, return %, and equity curve placeholder.
- Tests for ledger reconciliation, trade history, portfolio calculations, market history, audit records, and event ordering.

Remaining Sprint 1 follow-up:

- FX-002 Admin Audit: add the `ADMIN_ADJUSTMENT` workflow and complete market-edit audit coverage.
- Add concurrency-safe trade execution.
- Add a full charting implementation for the equity curve.

## P0 - Correctness and Safety Foundation - 68% Complete

Goal: make the money/market core reliable before adding new features.

1. Add Prisma migrations - complete for FX-001
   - Initial migration committed under `prisma/migrations`.
   - Follow-up: docs and scripts still need a full migrate-first workflow.

2. Add ledger-based mock balance accounting - complete for core flows
   - Completed: `AccountLedgerEntry` model.
   - Completed: seed grants, trade spends, settlement payouts, and void refunds.
   - Completed: correction support, metadata, admin attribution, idempotency keys, and reconciliation utilities.
   - Remaining: `ADMIN_ADJUSTMENT` workflow.
   - Remaining: operational reconciliation reports/alerts.

3. Split domain services - not started
   - Move trade execution out of `lib/db-amm.ts`.
   - Move settlement/void logic into dedicated services.
   - Move leaderboard recalculation into its own service.
   - Add typed domain errors.

4. Add concurrency protection - not started
   - Review Prisma transaction isolation.
   - Ensure market pools and user balances cannot be double-spent or overwritten by simultaneous trades.
   - Add tests for simultaneous buys on the same market and simultaneous buys by the same user.

5. Add admin audit log - next milestone
   - Completed: settle, lock, unlock, and void audit records.
   - Completed: actor, action, market/week/player, previous state, next state, timestamp, and optional reason.
   - Remaining: FX-002 Admin Audit for market edit and admin adjustment audit flows.

## P1 - Auth, Authorization, and Security Hardening

Goal: keep mock auth but prevent accidental production-grade assumptions.

1. Replace raw `userId` cookie
   - Use signed cookies or server-side session IDs.
   - Keep demo account selection but make session tampering harder.

2. Add CSRF protection
   - Protect all cookie-authenticated POST routes.
   - Cover trades, settlements, login/logout if appropriate.

3. Expand authorization model
   - Replace boolean-only admin checks with roles or permissions.
   - Start with `TRADER`, `ADMIN`, `SETTLEMENT_OPERATOR`, `AUDITOR`.

4. Replace in-memory rate limiting
   - Use a durable/shared store before deployment.
   - Keep route-specific limits for trade and settlement routes.

5. Add security tests
   - Non-admin cannot settle.
   - Logged-out user cannot trade.
   - Forged user ID cannot trade as another account.
   - Invalid/unsigned session is rejected.

## P2 - Testing and Developer Workflow

Goal: make changes safer and easier for future agents or contributors.

1. Add E2E smoke tests
   - Login as demo user.
   - Buy YES.
   - Confirm portfolio updates.
   - Login as admin.
   - Settle player markets.
   - Confirm payouts/leaderboard update.

2. Add test factories
   - Users, players, weeks, games, markets, positions, trades.
   - Keep DB tests compact and readable.

3. Add a single verify script
   - `npm run verify` should run lint, typecheck, unit tests, build, and optionally a11y.

4. Add reset scripts
   - `npm run db:reset`
   - `npm run db:seed`
   - `npm run db:fresh`

5. Add CI
   - Run lint, typecheck, tests, and build on PR.
   - Run a11y tests on scheduled/manual or full CI if runtime is acceptable.

## P3 - Product MVP Expansion

Goal: improve product completeness while preserving free-play constraints.

1. Add kickoff-based market locking
   - Scheduled job or server-side guard.
   - Trade route should reject markets past kickoff even if status is stale.

2. Add multi-week support
   - Week selector.
   - Week-specific leaderboard and portfolio filtering.
   - Admin week management.

3. Add fantasy scoring import workflow
   - Admin import CSV/manual table.
   - Calculate positional ranks from half-PPR scoring.
   - Settle markets from rank results.

4. Add transaction history
   - Portfolio trade list.
   - Ledger activity feed.
   - Settlement payout/refund history.

5. Add market discovery
   - Player search.
   - Team filters.
   - Sort by price, liquidity, kickoff, position, status.

## P4 - Performance and Scale

Goal: prepare for more users, markets, and live updates.

1. Add incremental leaderboard read model
   - Avoid full user/position recalculation in settlement transactions.
   - Update affected users or process recalculation asynchronously.

2. Add background jobs
   - Market locking.
   - Leaderboard recalculation.
   - Rank import processing.
   - Audit/event processing.

3. Add market price update strategy
   - Polling first.
   - SSE/WebSocket later if needed.

4. Add pagination
   - Trades.
   - Positions.
   - Admin market lists.
   - Leaderboard.

5. Add observability
   - Structured logs.
   - Request IDs.
   - Basic metrics around trade failures, settlement runs, and API latency.

## P5 - Solana Planning, Later

Goal: plan blockchain support without contaminating the free-play MVP.

1. Write a Solana architecture proposal
   - Testnet-only.
   - No deposits or withdrawals.
   - No mainnet SOL.
   - No production wagering.

2. Define account-linking model
   - Wallet address as identity link only.
   - Preserve mock credits.
   - No custody.

3. Define what belongs on-chain vs off-chain
   - Market state.
   - Trades.
   - Settlement attestations.
   - Leaderboards.

4. Complete legal/compliance review before any real-money direction.

## Suggested First Implementation Sprint

1. FX-002 Admin Audit: add admin adjustment and market edit workflows with immutable audit records.
2. Add tests for non-admin settlement rejection and admin authorization boundaries.
3. Move trade execution to `src/server/services/trade.service.ts`.
4. Add typed domain errors.
5. Add concurrent trade safety tests.
6. Remove legacy `lib/store.tsx` after confirming no imports.
