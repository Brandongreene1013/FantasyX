# FantasyX / Sunday Markets Handoff

## Summary

FantasyX is a database-backed, free-play NFL fantasy prediction market MVP. Users trade mock-credit YES/NO shares on whether players finish Top 3, Top 5, or Top 10 at their weekly half-PPR positional rank.

No real-money wagering, deposits, withdrawals, private keys, wallet custody, mainnet SOL, or production crypto settlement are implemented. Solana is a future direction only.

## Current State

- Next.js App Router UI with mobile-first pages.
- Prisma/Postgres persistence through Docker Compose.
- Mock demo-account auth using a secure httpOnly cookie named `fantasyx_user_id`.
- `/login` lets users select seeded demo accounts.
- Trades, portfolio, and admin settlement use the authenticated session user.
- Trades do not trust `userId` from client payloads.
- Admin settlement route requires `user.isAdmin`.
- FX-001 Append-Only Ledger Foundation is complete: true ledger service, reconciliation utilities, migration, metadata, admin attribution, correction type, append-only protection, and idempotency safeguards.
- Accessibility hardening and axe tests are in place.

## Features Completed

- Mock account login with httpOnly cookie session.
- Protected `/markets`, `/portfolio`, `/history`, and `/admin` routes.
- Database-backed slate, trading, portfolio, leaderboard, settlement, history, ledger, and market events.
- Constant-product AMM mock-credit trading.
- Append-only account ledger entries for seed grants, trade spends, settlement payouts, and void refunds.
- Ledger correction entries and admin-attributed ledger entries.
- Transaction-safe ledger service for every balance-changing trade, payout, and refund flow.
- Ledger reconciliation utilities with mismatch details.
- Stable idempotency keys for settlement payouts and void refunds.
- Market opening price, volume, and open interest tracking.
- Unified chronological market events.
- Admin audit records for settlement, void, lock, and unlock actions.
- Trade History page with week, player, position, market, and status filters.
- Portfolio history with open/closed positions, realized/unrealized P&L, average entry, current value, return %, and equity curve placeholder.
- Market Timeline component on `/markets` and `/history`.

## Tech Stack

- Next.js 15
- React 19
- TypeScript
- Tailwind CSS
- Prisma 6
- PostgreSQL 16 via Docker
- Zod
- Vitest
- Playwright + axe-core
- Lucide React

## Setup

```powershell
cd "C:\Users\brand\OneDrive\Desktop\FantasyX"
npm install
docker compose up -d
npm run prisma:generate
npm run prisma:push
npm run prisma:seed
npm run dev
```

Open `http://localhost:3000/login`.

## Environment

Required `.env` value:

```env
DATABASE_URL="postgresql://postgres:postgres@localhost:5432/fantasyx?schema=public"
```

`.env` is excluded from handoff archives.

## Database

Schema: `prisma/schema.prisma`

Seed: `prisma/seed.ts`

Main models:

- `User`
- `Player`
- `NflWeek`
- `Game`
- `Market`
- `Trade`
- `Position`
- `Settlement`
- `LeaderboardEntry`
- `AccountLedgerEntry`
- `MarketEvent`
- `AdminAuditLog`

Recent schema changes:

- Added enums: `LedgerEntryType`, `MarketEventType`, `AdminAuditAction`.
- Added `Market.openingPrice`, `Market.volume`, and `Market.openInterest`.
- Added `AccountLedgerEntry`.
- Added `AccountLedgerEntry.adminId`.
- Added `AccountLedgerEntry.metadata`.
- Added `LedgerEntryType.CORRECTION`.
- Added `MarketEvent`.
- Added `AdminAuditLog`.
- Added relations from users, markets, trades, and settlements to exchange-history records.

Migration:

- `prisma/migrations/20260628121000_fx001_append_only_ledger/migration.sql`
- `prisma/migrations/migration_lock.toml`

The migration includes indexes and append-only trigger protection for ledger update/delete attempts.

Ledger behavior:

- `AccountLedgerEntry` is append-only.
- Application code only reads or creates ledger rows.
- No app route exposes ledger update/delete behavior.
- Trade spend, settlement payout, void refund, and seed grant balance changes are represented by ledger rows.
- Settlement payout keys use `settlement_payout:{settlementId}:{userId}`.
- Void refund keys use `void_refund:{marketId}:{userId}`.
- The `idempotencyKey` column is unique to prevent duplicate balance mutations.

## Main Routes

- `/` - home and product explanation
- `/login` - demo account selection
- `/markets` - protected market slate and trading
- `/portfolio` - protected authenticated-user portfolio
- `/history` - protected trade history and market timeline
- `/leaderboard` - leaderboard
- `/admin` - protected admin settlement UI
- `/slate` - redirects to `/markets`

## API Routes

- `GET /api/auth/demo-users`
- `POST /api/auth/login`
- `POST /api/auth/logout`
- `GET /api/session`
- `GET /api/slate`
- `POST /api/trades`
- `GET /api/portfolio`
- `GET /api/trade-history`
- `GET /api/account-ledger`
- `GET /api/market-events`
- `GET /api/leaderboard`
- `POST /api/settlements`

New API routes from Sprint 1:

- `GET /api/trade-history`
- `GET /api/account-ledger`
- `GET /api/market-events`

## Core Logic Files

- `lib/auth.ts` - session and admin helpers
- `lib/session.ts` - cookie name constant safe for middleware/tests
- `lib/db-amm.ts` - database trading, settlement, void, leaderboard logic
- `lib/exchange-records.ts` - market event and admin audit record helpers
- `lib/ledger-service.ts` - transaction-safe ledger balance changes and reconciliation utilities
- `lib/amm.ts` - pure AMM math
- `lib/api-validation.ts` - Zod schemas
- `middleware.ts` - route protection and placeholder rate limiting

## Files Changed in Sprint 1

- `prisma/schema.prisma`
- `prisma/migrations/20260628121000_fx001_append_only_ledger/migration.sql`
- `prisma/migrations/migration_lock.toml`
- `prisma/seed.ts`
- `lib/db-amm.ts`
- `lib/exchange-records.ts`
- `lib/ledger-service.ts`
- `lib/db-serialization.ts`
- `lib/types.ts`
- `lib/client-api.ts`
- `lib/api-validation.ts`
- `app/api/trade-history/route.ts`
- `app/api/account-ledger/route.ts`
- `app/api/market-events/route.ts`
- `app/api/portfolio/route.ts`
- `app/api/settlements/route.ts`
- `app/history/page.tsx`
- `app/portfolio/page.tsx`
- `app/markets/page.tsx`
- `app/admin/page.tsx`
- `app/layout.tsx`
- `middleware.ts`
- `components/market-card.tsx`
- `components/market-timeline.tsx`
- `tests/money-market.test.ts`
- `ROADMAP.md`
- `HANDOFF.md`
- `TODO.md`

## Environment Variables

No new environment variables were added.

Required:

- `DATABASE_URL`

## Breaking Changes

- Database schema changed. Existing local databases must run `npm run prisma:push` before running the app.
- A committed migration now exists. Fresh shared environments should move toward `prisma migrate deploy`; local legacy DBs may still need `npm run prisma:push` until migration workflow is fully normalized.
- Seed now clears and recreates ledger, market event, and admin audit records.
- `/history` is a new protected route and requires login.

## Tests

Business logic:

```powershell
npm run test
```

Covers AMM price movement, ledger math, seed grant ledger rows, trade spend ledger rows, spend/balance behavior, position shares, locked/settled/void trade rejection, insufficient balance, settlement payout ledger rows, double-pay ledger prevention, void refund ledger rows, double-refund ledger prevention, forged `userId` rejection, ledger reconciliation, reconciliation mismatch details, ledger idempotency, correction metadata/admin attribution, trade history, portfolio calculations, market history, admin audit records, and market event ordering.

Accessibility:

```powershell
npm run test:a11y
```

Covers home, markets, portfolio, leaderboard, admin, and trade modal with axe.

## Last Verified Results

- `npm run prisma:generate` - passed
- `npm run prisma:push` - passed
- `npm run lint` - passed on 2026-06-28
- `npm run typecheck` - passed on 2026-06-28
- `npm test` - passed on 2026-06-28, 20 tests
- `npm run build` - passed on 2026-06-28
- `npm run prisma:seed` - passed
- `npm run test:a11y` - passed, 6 tests

Known non-blocking warning: Playwright dev server may show a future Next.js `allowedDevOrigins` warning for `127.0.0.1`.

## Known Issues

- A migration exists, but docs/scripts still need to fully switch from `prisma db push` to migrate-first workflows.
- In-memory rate limiting is only a placeholder.
- Demo auth has no passwords and is not production auth.
- `/markets` is route-protected so users choose an account before trading.
- Equity curve is a placeholder visualization, not a production chart.
- Ledger writes now use `lib/ledger-service.ts`, but trade/settlement orchestration still lives in `lib/db-amm.ts`.
- Trade execution still lacks explicit concurrency controls/row locking tests.
- `ADMIN_ADJUSTMENT` ledger type exists but has no UI/API workflow yet. This is the next recommended ticket.
- Legacy `lib/store.tsx` may still exist but should not be used for real app state.
- No Solana integration yet by design.

## Recommended Next Implementation Ticket

Next ticket: FX-002 Admin Audit.

Scope:

1. Add `ADMIN_ADJUSTMENT` UI/API workflow using `lib/ledger-service.ts`.
2. Add immutable audit records for admin adjustments and market edits.
3. Add admin authorization tests around every admin action.
4. Keep all balance changes routed through `lib/ledger-service.ts`.
