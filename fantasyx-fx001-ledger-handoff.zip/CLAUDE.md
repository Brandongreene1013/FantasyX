# Claude Code Start Here

You are continuing the FantasyX / Sunday Markets MVP in this folder.

## Product Direction

Build a free-play weekly NFL fantasy prediction market. Users trade mock-credit YES/NO shares on whether players finish Top 3, Top 5, or Top 10 at their position in weekly half-PPR fantasy scoring.

Important: do not add real-money wagering, deposits, withdrawals, wallet custody, mainnet SOL, or production crypto settlement. Solana support is future-only and should be designed separately later.

## Current State

- Next.js App Router + TypeScript + Tailwind.
- Prisma/Postgres database-backed MVP.
- Docker Compose runs local Postgres.
- Mock auth exists through `/login`.
- Selected demo account is stored in secure httpOnly cookie `fantasyx_user_id`.
- API routes derive the user from the session cookie.
- Trades must never trust client-submitted `userId`.
- Admin settlement APIs require `user.isAdmin`.
- Accessibility pass and axe tests are included.

## Key Files

- `HANDOFF.md` - full current handoff.
- `README.md` - setup and commands.
- `TODO.md` - prioritized next steps.
- `prisma/schema.prisma` - database schema.
- `prisma/seed.ts` - demo data.
- `lib/auth.ts` - session/admin helpers.
- `lib/session.ts` - session cookie constant.
- `lib/db-amm.ts` - database trade, settlement, void, leaderboard logic.
- `app/api/trades/route.ts` - authenticated trade route.
- `app/api/settlements/route.ts` - admin settlement route.
- `tests/money-market.test.ts` - core money/market tests.

## Run Locally

```powershell
docker compose up -d
npm run prisma:push
npm run prisma:seed
npm run dev
```

Open `http://localhost:3000/login`.

## Verify

```powershell
npm run lint
npm run typecheck
npm run test
npm run build
npm run test:a11y
```

## Good Next Task

Add committed Prisma migrations and an E2E smoke test for login -> buy YES -> portfolio update.
