import type { AdminAuditAction, MarketEventType, Prisma } from "@prisma/client";

export async function createMarketEvent(
  tx: Prisma.TransactionClient,
  input: {
    marketId: string;
    type: MarketEventType;
    userId?: string;
    tradeId?: string;
    settlementId?: string;
    priceBefore?: number;
    priceAfter?: number;
    liquidity?: number;
    volume?: number;
    openInterest?: number;
    note?: string;
  }
) {
  return tx.marketEvent.create({
    data: {
      marketId: input.marketId,
      type: input.type,
      userId: input.userId,
      tradeId: input.tradeId,
      settlementId: input.settlementId,
      priceBefore: input.priceBefore,
      priceAfter: input.priceAfter,
      liquidity: input.liquidity,
      volume: input.volume,
      openInterest: input.openInterest,
      note: input.note
    }
  });
}

export async function createAdminAuditLog(
  tx: Prisma.TransactionClient,
  input: {
    actorId: string;
    action: AdminAuditAction;
    marketId?: string;
    weekId?: string;
    playerId?: string;
    reason?: string;
    previousState?: string;
    nextState?: string;
  }
) {
  return tx.adminAuditLog.create({
    data: {
      actorId: input.actorId,
      action: input.action,
      marketId: input.marketId,
      weekId: input.weekId,
      playerId: input.playerId,
      reason: input.reason,
      previousState: input.previousState,
      nextState: input.nextState
    }
  });
}
