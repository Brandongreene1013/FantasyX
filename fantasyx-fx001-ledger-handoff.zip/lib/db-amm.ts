import type { Market as DbMarket, MarketResult, Prisma, ThresholdType, TradeSide } from "@prisma/client";
import { executeBuy } from "@/lib/amm";
import type { Market as ClientMarket, Side } from "@/lib/types";
import { toNumber } from "@/lib/db-serialization";
import { createAdminAuditLog, createMarketEvent } from "@/lib/exchange-records";
import { applyLedgerBalanceChange } from "@/lib/ledger-service";

export async function executeDbBuy(
  tx: Prisma.TransactionClient,
  input: {
    userId: string;
    marketId: string;
    side: TradeSide;
    spend: number;
  }
) {
  const [user, market] = await Promise.all([
    tx.user.findUnique({ where: { id: input.userId } }),
    tx.market.findUnique({ where: { id: input.marketId } })
  ]);

  if (!user) {
    throw new Error("User not found");
  }
  if (!market) {
    throw new Error("Market not found");
  }
  if (market.status !== "OPEN") {
    throw new Error("Market is not open");
  }

  const balance = toNumber(user.mockBalance);
  if (input.spend <= 0) {
    throw new Error("Trade amount must be positive");
  }
  if (input.spend > balance) {
    throw new Error("Insufficient mock credit balance");
  }

  const executableMarket: ClientMarket = {
    id: market.id,
    playerId: market.playerId,
    week: 1,
    position: market.position,
    threshold: market.thresholdType,
    yesPool: toNumber(market.yesPool),
    noPool: toNumber(market.noPool),
    liquidity: toNumber(market.yesPool) + toNumber(market.noPool),
    status: "OPEN",
    result: market.result
  };

  const { market: nextMarket, quote } = executeBuy(executableMarket, input.side as Side, input.spend);
  const yesPrice = nextMarket.noPool / (nextMarket.yesPool + nextMarket.noPool);
  const noPrice = 1 - yesPrice;
  const nextVolume = toNumber(market.volume) + input.spend;
  const nextOpenInterest = toNumber(market.openInterest) + quote.shares;
  const nextLiquidity = nextMarket.yesPool + nextMarket.noPool;

  const trade = await tx.trade.create({
    data: {
      userId: input.userId,
      marketId: input.marketId,
      side: input.side,
      spend: input.spend,
      shares: quote.shares,
      priceBefore: quote.priceBefore,
      priceAfter: quote.priceAfter
    }
  });

  await tx.market.update({
    where: { id: input.marketId },
    data: {
      yesPool: nextMarket.yesPool,
      noPool: nextMarket.noPool,
      yesPrice,
      noPrice,
      volume: nextVolume,
      openInterest: nextOpenInterest
    }
  });

  await applyLedgerBalanceChange(tx, {
    userId: input.userId,
    type: "TRADE_SPEND",
    amount: -input.spend,
    marketId: input.marketId,
    tradeId: trade.id,
    idempotencyKey: `trade_spend:${trade.id}`,
    reason: `Bought ${input.side} shares`,
    metadata: {
      side: input.side,
      shares: quote.shares,
      priceBefore: quote.priceBefore,
      priceAfter: quote.priceAfter
    }
  });

  await createMarketEvent(tx, {
    marketId: input.marketId,
    type: "TRADE",
    userId: input.userId,
    tradeId: trade.id,
    priceBefore: quote.priceBefore,
    priceAfter: quote.priceAfter,
    liquidity: nextLiquidity,
    volume: nextVolume,
    openInterest: nextOpenInterest,
    note: `${input.side} buy for ${input.spend.toFixed(2)} mock credits`
  });

  await createMarketEvent(tx, {
    marketId: input.marketId,
    type: "PRICE_CHANGE",
    userId: input.userId,
    tradeId: trade.id,
    priceBefore: quote.priceBefore,
    priceAfter: quote.priceAfter,
    liquidity: nextLiquidity,
    volume: nextVolume,
    openInterest: nextOpenInterest,
    note: "Price changed after trade execution"
  });

  const currentPosition = await tx.position.findUnique({
    where: {
      userId_marketId: {
        userId: input.userId,
        marketId: input.marketId
      }
    }
  });

  await tx.position.upsert({
    where: {
      userId_marketId: {
        userId: input.userId,
        marketId: input.marketId
      }
    },
    create: {
      userId: input.userId,
      marketId: input.marketId,
      yesShares: input.side === "YES" ? quote.shares : 0,
      noShares: input.side === "NO" ? quote.shares : 0,
      costBasis: input.spend
    },
    update: {
      yesShares: toNumber(currentPosition?.yesShares ?? 0) + (input.side === "YES" ? quote.shares : 0),
      noShares: toNumber(currentPosition?.noShares ?? 0) + (input.side === "NO" ? quote.shares : 0),
      costBasis: toNumber(currentPosition?.costBasis ?? 0) + input.spend
    }
  });

  return trade;
}

export async function settleDbMarket(
  tx: Prisma.TransactionClient,
  input: {
    marketId: string;
    result: MarketResult;
    settledById?: string;
    fantasyPoints?: number;
    positionalRank?: number;
    reason?: string;
  }
) {
  const existingMarket = await tx.market.findUnique({
    where: { id: input.marketId },
    include: { positions: true }
  });

  if (!existingMarket) {
    throw new Error("Market not found");
  }
  if (existingMarket.status === "SETTLED") {
    throw new Error("Market is already settled");
  }
  if (existingMarket.status === "VOID") {
    throw new Error("Voided market cannot be settled");
  }

  const market = await tx.market.update({
    where: { id: input.marketId },
    data: {
      status: "SETTLED",
      result: input.result
    }
  });

  const settlement = await tx.settlement.upsert({
    where: { marketId: input.marketId },
    create: {
      marketId: input.marketId,
      settledById: input.settledById,
      result: input.result,
      fantasyPoints: input.fantasyPoints,
      positionalRank: input.positionalRank
    },
    update: {
      settledById: input.settledById,
      result: input.result,
      fantasyPoints: input.fantasyPoints,
      positionalRank: input.positionalRank,
      settledAt: new Date()
    }
  });

  await createMarketEvent(tx, {
    marketId: input.marketId,
    type: "SETTLE",
    userId: input.settledById,
    settlementId: settlement.id,
    priceAfter: toNumber(existingMarket.yesPrice),
    liquidity: toNumber(existingMarket.yesPool) + toNumber(existingMarket.noPool),
    volume: toNumber(existingMarket.volume),
    openInterest: toNumber(existingMarket.openInterest),
    note: input.reason ?? `Market settled ${input.result}`
  });

  if (input.settledById) {
    await createAdminAuditLog(tx, {
      actorId: input.settledById,
      action: "SETTLEMENT",
      marketId: input.marketId,
      weekId: existingMarket.weekId,
      playerId: existingMarket.playerId,
      reason: input.reason ?? `Market settled ${input.result}`,
      previousState: existingMarket.status,
      nextState: `SETTLED:${input.result}`
    });
  }

  await payWinningPositions(tx, existingMarket, input.result, settlement.id, input.settledById);
  await refreshLeaderboardForWeek(tx, existingMarket.weekId);

  return market;
}

export async function settleDbPlayerMarkets(
  tx: Prisma.TransactionClient,
  input: {
    playerId: string;
    weekId: string;
    rank: number;
    settledById?: string;
    fantasyPoints?: number;
    reason?: string;
  }
) {
  const markets = await tx.market.findMany({
    where: {
      playerId: input.playerId,
      weekId: input.weekId
    },
    include: { positions: true }
  });

  if (markets.length === 0) {
    throw new Error("No markets found for player and week");
  }

  const settled = [];
  for (const market of markets) {
    if (market.status === "SETTLED" || market.status === "VOID") {
      continue;
    }

    const result = input.rank <= thresholdToRank(market.thresholdType) ? "YES" : "NO";
    const updated = await tx.market.update({
      where: { id: market.id },
      data: {
        status: "SETTLED",
        result
      }
    });

    const settlement = await tx.settlement.upsert({
      where: { marketId: market.id },
      create: {
        marketId: market.id,
        settledById: input.settledById,
        result,
        fantasyPoints: input.fantasyPoints,
        positionalRank: input.rank
      },
      update: {
        settledById: input.settledById,
        result,
        fantasyPoints: input.fantasyPoints,
        positionalRank: input.rank,
        settledAt: new Date()
      }
    });

    await createMarketEvent(tx, {
      marketId: market.id,
      type: "SETTLE",
      userId: input.settledById,
      settlementId: settlement.id,
      priceAfter: toNumber(market.yesPrice),
      liquidity: toNumber(market.yesPool) + toNumber(market.noPool),
      volume: toNumber(market.volume),
      openInterest: toNumber(market.openInterest),
      note: input.reason ?? `Player rank ${input.rank} settled market ${result}`
    });

    if (input.settledById) {
      await createAdminAuditLog(tx, {
        actorId: input.settledById,
        action: "SETTLEMENT",
        marketId: market.id,
        weekId: market.weekId,
        playerId: market.playerId,
        reason: input.reason ?? `Player rank ${input.rank}`,
        previousState: market.status,
        nextState: `SETTLED:${result}`
      });
    }

    await payWinningPositions(tx, market, result, settlement.id, input.settledById);
    settled.push(updated);
  }

  await refreshLeaderboardForWeek(tx, input.weekId);
  return settled;
}

export async function lockDbMarket(tx: Prisma.TransactionClient, marketId: string, actorId?: string, reason?: string) {
  const market = await tx.market.findUnique({ where: { id: marketId } });
  if (!market) {
    throw new Error("Market not found");
  }
  if (market.status === "SETTLED" || market.status === "VOID") {
    throw new Error("Finalized market cannot be locked");
  }
  const updated = await tx.market.update({ where: { id: marketId }, data: { status: "LOCKED" } });
  await createMarketEvent(tx, {
    marketId,
    type: "LOCK",
    userId: actorId,
    priceAfter: toNumber(market.yesPrice),
    liquidity: toNumber(market.yesPool) + toNumber(market.noPool),
    volume: toNumber(market.volume),
    openInterest: toNumber(market.openInterest),
    note: reason ?? "Market locked"
  });
  if (actorId) {
    await createAdminAuditLog(tx, {
      actorId,
      action: "LOCK",
      marketId,
      weekId: market.weekId,
      playerId: market.playerId,
      reason: reason ?? "Market locked",
      previousState: market.status,
      nextState: updated.status
    });
  }
  return updated;
}

export async function openDbMarket(tx: Prisma.TransactionClient, marketId: string, actorId?: string, reason?: string) {
  const market = await tx.market.findUnique({ where: { id: marketId } });
  if (!market) {
    throw new Error("Market not found");
  }
  if (market.status !== "LOCKED") {
    throw new Error("Only locked markets can be reopened");
  }
  const updated = await tx.market.update({ where: { id: marketId }, data: { status: "OPEN" } });
  await createMarketEvent(tx, {
    marketId,
    type: "UNLOCK",
    userId: actorId,
    priceAfter: toNumber(market.yesPrice),
    liquidity: toNumber(market.yesPool) + toNumber(market.noPool),
    volume: toNumber(market.volume),
    openInterest: toNumber(market.openInterest),
    note: reason ?? "Market reopened"
  });
  if (actorId) {
    await createAdminAuditLog(tx, {
      actorId,
      action: "UNLOCK",
      marketId,
      weekId: market.weekId,
      playerId: market.playerId,
      reason: reason ?? "Market reopened",
      previousState: market.status,
      nextState: updated.status
    });
  }
  return updated;
}

export async function voidDbMarket(tx: Prisma.TransactionClient, marketId: string, actorId?: string, reason?: string) {
  const market = await tx.market.findUnique({
    where: { id: marketId },
    include: { positions: true }
  });

  if (!market) {
    throw new Error("Market not found");
  }
  if (market.status === "SETTLED") {
    throw new Error("Settled market cannot be voided");
  }
  if (market.status === "VOID") {
    throw new Error("Market is already void");
  }

  const updated = await tx.market.update({
    where: { id: marketId },
    data: {
      status: "VOID",
      result: null
    }
  });

  await createMarketEvent(tx, {
    marketId,
    type: "VOID",
    userId: actorId,
    priceAfter: toNumber(market.yesPrice),
    liquidity: toNumber(market.yesPool) + toNumber(market.noPool),
    volume: toNumber(market.volume),
    openInterest: toNumber(market.openInterest),
    note: reason ?? "Market voided"
  });

  if (actorId) {
    await createAdminAuditLog(tx, {
      actorId,
      action: "VOID",
      marketId,
      weekId: market.weekId,
      playerId: market.playerId,
      reason: reason ?? "Market voided",
      previousState: market.status,
      nextState: "VOID"
    });
  }

  for (const position of market.positions) {
    if (toNumber(position.realizedPayout) > 0) {
      continue;
    }
    const refund = toNumber(position.costBasis);
    if (refund <= 0) {
      continue;
    }

    await applyLedgerBalanceChange(tx, {
      userId: position.userId,
      type: "VOID_REFUND",
      amount: refund,
      marketId,
      adminId: actorId,
      idempotencyKey: `void_refund:${marketId}:${position.userId}`,
      reason: reason ?? "Market void refund",
      metadata: {
        positionId: position.id,
        costBasis: refund
      }
    });
    await tx.position.update({
      where: { id: position.id },
      data: {
        realizedPayout: refund
      }
    });
  }

  await refreshLeaderboardForWeek(tx, market.weekId);
  return updated;
}

async function payWinningPositions(
  tx: Prisma.TransactionClient,
  market: DbMarket & { positions: Array<{ id: string; userId: string; yesShares: unknown; noShares: unknown; realizedPayout: unknown }> },
  result: MarketResult,
  settlementId: string,
  adminId?: string
) {
  for (const position of market.positions) {
    if (toNumber(position.realizedPayout) > 0) {
      continue;
    }

    const payout = result === "YES" ? toNumber(position.yesShares) : toNumber(position.noShares);
    if (payout <= 0) {
      await tx.position.update({
        where: { id: position.id },
        data: { realizedPayout: 0 }
      });
      continue;
    }

    await applyLedgerBalanceChange(tx, {
      userId: position.userId,
      type: "SETTLEMENT_PAYOUT",
      amount: payout,
      marketId: market.id,
      settlementId,
      adminId,
      idempotencyKey: `settlement_payout:${settlementId}:${position.userId}`,
      reason: `Winning ${result} shares paid`,
      metadata: {
        positionId: position.id,
        result,
        yesShares: toNumber(position.yesShares),
        noShares: toNumber(position.noShares)
      }
    });
    await tx.position.update({
      where: { id: position.id },
      data: {
        realizedPayout: payout
      }
    });
  }
}

async function refreshLeaderboardForWeek(tx: Prisma.TransactionClient, weekId: string) {
  const users = await tx.user.findMany({
    include: {
      positions: {
        include: { market: true }
      }
    }
  });

  const rows = users
    .map((user) => {
      const markedValue = user.positions.reduce((total, position) => {
        const market = position.market;
        if (market.status === "SETTLED" || market.status === "VOID") {
          return total;
        }
        return total + toNumber(position.yesShares) * toNumber(market.yesPrice) + toNumber(position.noShares) * toNumber(market.noPrice);
      }, 0);
      const pnl = toNumber(user.mockBalance) + markedValue - toNumber(user.startingBalance);
      return { user, pnl };
    })
    .sort((a, b) => b.pnl - a.pnl);

  for (const [index, row] of rows.entries()) {
    await tx.leaderboardEntry.upsert({
      where: {
        userId_weekId: {
          userId: row.user.id,
          weekId
        }
      },
      create: {
        userId: row.user.id,
        weekId,
        pnl: row.pnl,
        rank: index + 1
      },
      update: {
        pnl: row.pnl,
        rank: index + 1
      }
    });
  }
}

function thresholdToRank(threshold: ThresholdType) {
  if (threshold === "TOP_3") {
    return 3;
  }
  if (threshold === "TOP_5") {
    return 5;
  }
  return 10;
}
