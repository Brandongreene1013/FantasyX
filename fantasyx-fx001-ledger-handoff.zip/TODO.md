# TODO

## P0 - Next Implementation Ticket

1. FX-002 Admin Audit: add `ADMIN_ADJUSTMENT` UI/API workflow with ledger and admin audit records.
2. Add immutable audit coverage for market edits.
3. Add admin authorization tests for adjustment, settlement, void, lock, unlock, and market edit actions.
4. Add an admin-facing audit history view.
5. Add E2E smoke tests for login -> trade -> portfolio and admin -> settlement -> payout.

## P1 - Newly Discovered Technical Debt

1. Trade, settlement, void, leaderboard, event, and audit orchestration still share `lib/db-amm.ts`; split into services.
2. `User.mockBalance` is still a mutable cached balance; add scheduled reconciliation checks and admin-visible mismatch alerts.
3. Settlement and void idempotency rely partly on position payout state; move toward explicit payout/refund records.
4. Migration workflow exists but setup docs/scripts still reference `prisma db push`.
5. Market events are recorded, but no market detail page exists for a single full timeline.
6. Equity curve is a placeholder using simple bars instead of a real chart component.
7. `ADMIN_ADJUSTMENT` enum value exists without product workflow.
8. No pagination yet for trade history, ledger entries, or market events.

## P2 - Bugs / Risk Areas To Watch

1. Concurrent trades may still read stale market pool or user balance data.
2. The append-only trigger is committed in migration; local `prisma db push` databases do not automatically receive trigger behavior.
3. Seed resets all exchange history; this is fine for local demo but not for persistent environments.
4. In-memory rate limiting is not durable across instances.
5. Demo auth uses mock accounts and is not production authentication.
6. Legacy `lib/store.tsx` can confuse future work if accidentally imported.
7. Trade request idempotency keys are not implemented yet; only ledger mutations have idempotency coverage.

## P3 - Future Improvements

1. Add kickoff-based automatic market locking.
2. Add multi-week slate navigation.
3. Add player search, team filters, and market sorting.
4. Add fantasy rank/scoring import workflow.
5. Add richer leaderboard filtering by week.
6. Add market detail pages with full event timelines and price/liquidity charts.
7. Replace browser event refreshes with query/mutation invalidation.

## P4 - Nice-To-Have Enhancements

1. Add a real chart library for equity curves and market history.
2. Add CSV export for trade history and ledger entries.
3. Add admin notes directly from market timeline.
4. Add user-facing account statement page from ledger entries.
5. Add a single `npm run verify` command for lint, typecheck, tests, and build.

## P5 - Later Solana Planning

1. Keep Solana design separate from the free-play MVP.
2. Start with testnet-only wallet identity linking.
3. Do not add deposits, withdrawals, custody, mainnet SOL, or real-money wagering until the free-play product is validated and reviewed.
